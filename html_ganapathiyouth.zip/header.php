<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Ganapathi Youth</title>

  <!-- Bootstrap -->
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="css/font-awesome.min.css">
  <link href="css/animate.min.css" rel="stylesheet">
  <link href="css/prettyPhoto.css" rel="stylesheet">
  <link href="css/style.css" rel="stylesheet">

  <link href="css/responsive.css" rel="stylesheet">
  <!-- new -->
<link href="css/marquee.css" rel="stylesheet">
<link href="css/newslider.css" rel="stylesheet">

<link href="css/groupcarsouelslider.css" rel="stylesheet">
  <!-- =======================================================
    Theme Name: Gp
    Theme URL: https://bootstrapmade.com/gp-free-multipurpose-html-bootstrap-templat/
    Author: BootstrapMade
    Author URL: https://bootstrapmade.com
  ======================================================= -->

</head>

<body class="homepage">
  <header id="header">

    <nav class="navbar navbar-fixed-top" role="banner">
<!--       <h5 style="color:white;"><center>శ్రీ బాల గణపతి యూత్</center></h5>
 -->      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
          <a class="navbar-brand" href="index.php"><img src="siva_images/balaganapathilogo.png"></a>

        </div>
     
          <!-- /logo -->
          
   
        <div class="collapse navbar-collapse navbar-right">
          <ul class="nav navbar-nav">
            <li class=""><a href="./">Home</a></li>
            <!-- <li><a href="about-us.php">About Us</a></li> -->
            <li><a href="services">Events</a></li>
            <li><a href="portfolio">Portfolio</a></li>
            <li><a href="blog">Blog</a></li>
            <li><a href="contact-us">Contact</a></li>
          </ul>
        </div>

      </div>
      <!--/.container-->

    </nav>
    <!--/nav-->

  </header>

 
  <!--/header-->
