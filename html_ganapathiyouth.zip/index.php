<?php include('header.php')?>


  <div class="slider">
    
<div id="themeSlider" class="carousel slide" data-ride="carousel">
    <ol class="carousel-indicators">
        <li data-target="#themeSlider" data-slide-to="0" class="active"></li>
        <li data-target="#themeSlider" data-slide-to="1"></li>
        <li data-target="#themeSlider" data-slide-to="2"></li>
    </ol>

    <div class="carousel-inner">
        <div class="item active">
            <div class="imgOverlay"></div>
               <img src="siva_images/banners/ganesh312.jpg" class="img-responsive" alt="">
            <div class="carousel-caption">
                <h3>First slide</h3>
                <p>Nulla vitae elit libero, a pharetra augue mollis interdum.</p>
            </div>
        </div>
        <div class="item">
          <div class="imgOverlay"></div>
           <img src="siva_images/banners/ganesh231.jpg" class="img-responsive" alt="">
            <div class="carousel-caption">
                <h3>Second slide</h3>
                <p>Nulla vitae elit libero, a pharetra augue mollis interdum.</p>
            </div>
        </div>
        <div class="item">
          <div class="imgOverlay"></div>
            <img src="siva_images/banners/ganesh123.jpg" class="img-responsive" alt="">
            <div class="carousel-caption">
                <h3>Third slide</h3>
                <p>Nulla vitae elit libero, a pharetra augue mollis interdum.</p>
            </div>
        </div>
    </div>

    <a class="left carousel-control" href="#themeSlider" data-slide="prev">
        <span class="fa fa-chevron-left"></span>
    </a>
    <a class="right carousel-control"href="#themeSlider" data-slide="next">
        <span class="fa fa-chevron-right"></span>
    </a>
</div>
  </div>
  
<?php include('teammembers.php')?>

<!-- animated text newslider.css -->

  <section class="mids" id="middle">
    <div class="container">
         <div class="center wow fadeInDown">
        <h2>The programs we are conducting</h2>
        <p class="lead">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut <br> et dolore magna aliqua. Ut enim ad minim veniam</p>
      </div>
      <div class="row">
        <div class="col-sm-6">
       <div class="bs-example" data-example-id="simple-carousel">
      <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
          <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
          <li data-target="#carousel-example-generic" data-slide-to="1"></li>
          <li data-target="#carousel-example-generic" data-slide-to="2"></li>
          <li data-target="#carousel-example-generic" data-slide-to="3"></li>
          <li data-target="#carousel-example-generic" data-slide-to="4"></li>
            <li data-target="#carousel-example-generic" data-slide-to="5"></li>
        </ol>
        <!-- TEXT COLOR  #AF2828 -->
        <!-- year color  E81212 -->
        <div class="carousel-inner" role="listbox">
          <div class="item active">
            <img src="siva_images/events/ganesh13.jpg" alt="First slide">
             <div class="carousel-caption">
        <h2 class="animatedtext">2013 సంవత్సరం గణపతి </h2>
          
      </div>

          </div>
          <div class="item">
            <img src="siva_images/events/ganesh14.jpg" alt="First slide">
             <div class="carousel-caption">
               <h2 class="animatedtext">2014 సంవత్సరం గణపతి </h2>
            </div>

             </div>
             <div class="item">
            <img src="siva_images/events/ganesh15.jpg" alt="First slide">
             <div class="carousel-caption">
              <h2 class="animatedtext">2015 సంవత్సరం గణపతి </h2>     
            </div>

             </div>
             <div class="item">
            <img src="siva_images/events/ganesh16.jpg" alt="First slide">
             <div class="carousel-caption">
                <h2 class="animatedtext">2016 సంవత్సరం గణపతి </h2>        
          </div>
      </div>
          <div class="item">
            <img src="siva_images/events/ganesh17.jpg" alt="First slide">
             <div class="carousel-caption">
                <h2 class="animatedtext">2017 సంవత్సరం గణపతి </h2>        
          </div>
         </div>
          <div class="item">
            <img src="siva_images/events/ganesh18.jpg" alt="First slide">
             <div class="carousel-caption">
                <h2 class="animatedtext">2018 సంవత్సరం గణపతి </h2>        
          </div>
        </div>
          <!-- <div class="item">
             <img src="https://naturemed.org/wp-content/uploads/2019/04/luke-brugger-30428-unsplash.jpg" alt="First slide">
         </div> -->
        </div>
        
         <a class="left carousel-control" href="#carousel-example-generic" data-slide="prev">
        <span class="fa fa-chevron-left"></span>
    </a>
    <a class="right carousel-control"href="#carousel-example-generic" data-slide="next">
        <span class="fa fa-chevron-right"></span>
    </a>
      </div>
    </div>
    <!-- /example -->

        </div>
        <!--/.col-sm-6-->
<!-- members -->
        <div class="col-sm-6 wow fadeInDown">
          <div class="accordion">
            
            <div class="panel-group" id="accordion1">
              <div class="panel panel-default">
                <div class="panel-heading active">
                  <h3 class="panel-title">
                      <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapseTwo1">
                       వినాయక చవితి
                        <i class="fa fa-angle-right pull-right"></i>
                      </a>
                    </h3>
                </div>
                <div id="collapseTwo1" class="panel-collapse collapse">
                  <div class="panel-body">
                    <div class="media accordion-inner">
                      <div class="pull-left">
                        <img class="img-responsive" src="siva_images/events/ganesh18.jpg">
                      </div>
                      <div class="media-body">
                        <h4>Adipisicing elit</h4>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div class="panel panel-default">
                <div class="panel-heading">
                  <h3 class="panel-title">
                    <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapseThree1">
                     పుష్కరాలకు
                      <i class="fa fa-angle-right pull-right"></i>
                    </a>
                  </h3>
                </div>
                <div id="collapseThree1" class="panel-collapse collapse">
                  <div class="panel-body">
                    <div class="media accordion-inner">
                      <div class="pull-left">
                        <img class="img-responsive" src="images/accordion1.png">
                      </div>
                      <div class="media-body">
                        <h4>Adipisicing elit</h4>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div class="panel panel-default">
                <div class="panel-heading">
                  <h3 class="panel-title">
                    <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapseFour1">
                     కృష్ణాష్టమి
                      <i class="fa fa-angle-right pull-right"></i>
                    </a>
                  </h3>
                </div>
                <div id="collapseFour1" class="panel-collapse collapse">
                  <div class="panel-body">
                    <div class="media accordion-inner">
                      <div class="pull-left">
                        <img class="img-responsive" src="images/accordion1.png">
                      </div>
                      <div class="media-body">
                        <h4>Adipisicing elit</h4>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!--/#accordion1-->
          </div>
        </div>
            <!-- members -->

      </div>
      <!--/.row-->
    </div>
    <!--/.container-->
  </section>
  <!--/#middle-->



  <section id="recent-works">
    <div class="container">
      <div class="center wow fadeInDown">
        <h2>Recent Works</h2>
        <p class="lead">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut <br> et dolore magna aliqua. Ut enim ad minim veniam</p>
      </div>

      <div class="row">
        <div class="col-xs-12 col-sm-4 col-md-3">
          <div class="recent-work-wrap">
            <a data-toggle="modal" id="image-modal" href="#myModal" class=""> <img class="img-responsive" src="images/portfolio/recent/item1.png" alt=""></a>            <div class="overlay">
              <div class="recent-work-inner">
                <h3><a href="#myModal">Business theme</a> </h3>
                <p>There are many variations of passages of Lorem Ipsum available, but the majority</p>
                <a class="preview" href="images/portfolio/full/item1.png" rel="prettyPhoto"><i class="fa fa-eye"></i> View</a>
              </div>
            </div>
          </div>
        </div>

        <div class="col-xs-12 col-sm-4 col-md-3">
          <div class="recent-work-wrap">
            <img class="img-responsive" src="images/portfolio/recent/item2.png" alt="">
            <div class="overlay">
              <div class="recent-work-inner">
                <h3><a href="#">Business theme</a></h3>
                <p>There are many variations of passages of Lorem Ipsum available, but the majority</p>
                <a class="preview" href="images/portfolio/full/item2.png" rel="prettyPhoto"><i class="fa fa-eye"></i> View</a>
              </div>
            </div>
          </div>
        </div>

        <div class="col-xs-12 col-sm-4 col-md-3">
          <div class="recent-work-wrap">
            <img class="img-responsive" src="images/portfolio/recent/item3.png" alt="">
            <div class="overlay">
              <div class="recent-work-inner">
                <h3><a href="#">Business theme </a></h3>
                <p>There are many variations of passages of Lorem Ipsum available, but the majority</p>
                <a class="preview" href="images/portfolio/full/item3.png" rel="prettyPhoto"><i class="fa fa-eye"></i> View</a>
              </div>
            </div>
          </div>
        </div>

        <div class="col-xs-12 col-sm-4 col-md-3">
          <div class="recent-work-wrap">
            <img class="img-responsive" src="images/portfolio/recent/item4.png" alt="">
            <div class="overlay">
              <div class="recent-work-inner">
                <h3><a href="#">MultiPurpose theme </a></h3>
                <p>There are many variations of passages of Lorem Ipsum available, but the majority</p>
                <a class="preview" href="images/portfolio/full/item4.png" rel="prettyPhoto"><i class="fa fa-eye"></i> View</a>
              </div>
            </div>
          </div>
        </div>

        <div class="col-xs-12 col-sm-4 col-md-3">
          <div class="recent-work-wrap">
            <img class="img-responsive" src="images/portfolio/recent/item5.png" alt="">
            <div class="overlay">
              <div class="recent-work-inner">
                <h3><a href="#">Business theme</a></h3>
                <p>There are many variations of passages of Lorem Ipsum available, but the majority</p>
                <a class="preview" href="images/portfolio/full/item5.png" rel="prettyPhoto"><i class="fa fa-eye"></i> View</a>
              </div>
            </div>
          </div>
        </div>

        <div class="col-xs-12 col-sm-4 col-md-3">
          <div class="recent-work-wrap">
            <img class="img-responsive" src="images/portfolio/recent/item6.png" alt="">
            <div class="overlay">
              <div class="recent-work-inner">
                <h3><a href="#">Business theme </a></h3>
                <p>There are many variations of passages of Lorem Ipsum available, but the majority</p>
                <a class="preview" href="images/portfolio/full/item6.png" rel="prettyPhoto"><i class="fa fa-eye"></i> View</a>
              </div>
            </div>
          </div>
        </div>

        <div class="col-xs-12 col-sm-4 col-md-3">
          <div class="recent-work-wrap">
            <img class="img-responsive" src="images/portfolio/recent/item7.png" alt="">
            <div class="overlay">
              <div class="recent-work-inner">
                <h3><a href="#">Business theme </a></h3>
                <p>There are many variations of passages of Lorem Ipsum available, but the majority</p>
                <a class="preview" href="images/portfolio/full/item7.png" rel="prettyPhoto"><i class="fa fa-eye"></i> View</a>
              </div>
            </div>
          </div>
        </div>

        <div class="col-xs-12 col-sm-4 col-md-3">
          <div class="recent-work-wrap">
            <img class="img-responsive" src="images/portfolio/recent/item8.png" alt="">
            <div class="overlay">
              <div class="recent-work-inner">
                <h3><a href="#">Business theme </a></h3>
                <p>There are many variations of passages of Lorem Ipsum available, but the majority</p>
                <a class="preview" href="images/portfolio/full/item8.png" rel="prettyPhoto"><i class="fa fa-eye"></i> View</a>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!--/.row-->
    </div>
    <!--/.container-->
  </section>
  <!--/#recent-works-->



<!-- Modal -->
<div class="modal fade" id="myModal"> <!-- Modal Window -->
    <div class="modal-dialog"> <!-- Modal Dialog -->
        <div class="modal-content"> <!-- Modal Content -->
            <div class="modal-header">
               <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
               <h4 class="modal-title">Modal Title</h4><!-- Modal title -->
            </div>
            <div class="modal-body"><!-- Begin Carousel Code -->
                <div id="carousel-example-generic" class="carousel slide"><!-- Wrapper for slides -->
                    <div class="carousel-inner center"><!-- Begin Carousel Images -->
                        <div class="item active">
                            <img src="http://placehold.it/600x400&text=Slide One" />
                        </div>

                      
                    </div><!-- End of Carousel Images -->

                    <!-- Controls -->
                    <a class="left carousel-control" href="#carousel-example-generic" data-slide="prev">
                        <span class="icon-prev"></span>
                    </a>
                    <a class="right carousel-control" href="#carousel-example-generic" data-slide="next">
                        <span class="icon-next"></span>
                    </a>
                </div><!-- End of Carousel -->

                <!-- Carousel Caption -->
                <div class="modal-header">
                    <div class="caption-text-carousel">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam nisi nulla, auctor ut efficitur nec, rhoncus ut turpis. Phasellus ultrices ante ac nunc iaculis vulputate. Quisque dapibus nibh orci, eget tristique ipsum hendrerit sit amet. Donec mauris dolor, lobortis in pulvinar at, imperdiet quis diam. Praesent dictum ex eget neque facilisis vehicula. </div>
                    <p>
                        <p>
                            Click <a href="#">here</a> for more details.</p> <!--In this link you can include a PDF file or anything else. -->
                </div> <!-- End Carousel Caption -->
            </div> <!-- End Carousel Code -->
        </div> <!-- /Modal Content -->
    </div><!-- /Modal Dialog -->
</div> <!-- /Modal -->
<?php include('footer.php')?>